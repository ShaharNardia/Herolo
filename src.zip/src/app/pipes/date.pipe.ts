
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'fixDatePipe'})
export class DatePipe implements PipeTransform {
  transform(dateToFix: string): string {
    if (dateToFix.includes('.')) {
  const thisDate = dateToFix.split('.');
  for (let i = 0 ; i < thisDate.length; i++) {
     if (thisDate[i].length === 1) {
       thisDate[i] = '0' + thisDate[i];
     }
  }
   return thisDate[2] + '-' + thisDate[1] + '-' + thisDate[0] ;
 } else if (dateToFix.length < 5) {
  return dateToFix + '-01-01';
} else if (dateToFix.length === 7) {
  return dateToFix + '-01';
} else {
   return dateToFix;
 }
}
}
