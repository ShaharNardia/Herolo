import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'noImg'})
export class NoImgPipe implements PipeTransform {
  transform(value: string): string {
    if (value.length < 5 || value === null || value === undefined ) {
      return 'http://weclipart.com/gimg/FD2690D3E055BA69/9iz6MzAiE.jpeg';
    } else {
      return value;
    }
  }
}


