
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'noAuthorPipe'})
export class AuthorPipe implements PipeTransform {
  transform(value: string): string {
    if (value === undefined) {return 'No author for this book'; } else { return value; }
}
}
