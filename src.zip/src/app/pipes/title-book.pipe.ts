import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'titleBook'})
export class TitleBookPipe implements PipeTransform {
  transform(value: string): string {
    let fixedValue = '';
    if (value !== undefined && value.length > 0) {
    const wordsArr = value.toLowerCase().replace(/[^A-Za-z ]/g, '').split(' ');
    for (let i = 0; i < wordsArr.length; i++) {
      fixedValue += wordsArr[i].charAt(0).toUpperCase() + wordsArr[i].substring(1) + ' ';
    }
  }
    return fixedValue;
  }
}
