import { Component } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { Store } from '@ngrx/store';
import { AppState } from './../../app.state';
import * as BookActions from './../../actions/book.actions';

export interface DeleteModel {
  id: number;
  title: string;
  message: string;
}
@Component({
    selector: 'app-deletepopup',
    templateUrl: './delete-popup.component.html'
})
export class DeleteBookPopupComponent extends DialogComponent<DeleteModel, boolean> implements DeleteModel {
  id: number;
  title: string;
  message: string;
  constructor(dialogService: DialogService, private store: Store<AppState>) {
    super(dialogService);
  }
  deleteBook() {
    this.store.dispatch(new BookActions.RemoveBook(this.id));
    this.dialogService.removeAll();
  }
  close() {
    this.dialogService.removeAll();
  }
}
