import { Component } from '@angular/core';
import { DialogComponent, DialogService } from 'ng2-bootstrap-modal';
import { Store } from '@ngrx/store';
import { Book } from './../../models/book.model';
import { AppState } from './../../app.state';
import * as BookActions from './../../actions/book.actions';
import { Observable } from 'rxjs';

export interface AddModel {
  index: number;
  id: string;
  authorName: string;
  publishedDate: string;
  bookTitle: string;
  img: string;
  title: string;
}
@Component({
    selector: 'app-addpopup',
    templateUrl: './add-popup.component.html'
})
export class AddBookPopupComponent extends DialogComponent<AddModel, boolean> implements AddModel {
  index: number;
  id: string;
  authorName: string;
  publishedDate: string;
  bookTitle: string;
  img: string;
  title: string;
  StoreBooksList: Book[];
  authorNameEmpty = false;
  publishedDateIncorrect  = false;
  bookTitleEmpty = false;
  bookTitleDuplicate = false;

  constructor(dialogService: DialogService, private store: Store<AppState>) {
    super(dialogService);
  }
  save() {

    if (this.stringValidator() && this.dateValidator() && this.checkDuplicateBookTitle()) {
    const d = new Date();
    const addBook: Book = {
    id: d.getTime().toString(),
    authorName: this.authorName,
    bookTitle:  this.bookTitle,
    publishedDate:  this.publishedDate,
    img: this.img
    };

    const updatedBook: Book = {
      id: this.id,
      authorName: this.authorName,
      bookTitle: this.bookTitle,
      publishedDate:  this.publishedDate,
      img: this.img
      };

    if (this.index === undefined) {
      this.store.dispatch(new BookActions.AddBook(addBook));
    } else {
      this.store.dispatch(new BookActions.EditBook(updatedBook, this.index));
    }
     this.dialogService.removeAll();
    }
  }
  close() {
    this.dialogService.removeAll();
  }
checkDuplicateBookTitle() {
this.store.select('book').subscribe(data => this.StoreBooksList = data);
for (let i = 0; i < this.StoreBooksList.length; i++) {
if (this.bookTitle.toLowerCase() === this.StoreBooksList[i].bookTitle.toLowerCase()) {
  if (this.id === this.StoreBooksList[i].id) {this.bookTitleDuplicate = false; return true;
      } else {this.bookTitleDuplicate = true; return false; }
    }
  }
  this.bookTitleDuplicate = false;
  return true;
}
  stringValidator() {
    let stringsValid  = true;
    if (this.authorName.length < 1) { this.authorNameEmpty = true; stringsValid  = false; } else {this.authorNameEmpty = false; }
    if (this.bookTitle.length < 1)  { this.bookTitleEmpty = true; stringsValid  = false; } else {this.bookTitleEmpty = false; }
    if (this.authorNameEmpty === false && this.bookTitleEmpty === false) {
      stringsValid  = true;
    }
    this.dateValidator();
    return stringsValid;
  }

  dateValidator() {
    let DateValid  = true;
    if (this.publishedDate.length < 1) {
    this.publishedDateIncorrect = true;
      DateValid  = false;
    } else {
      this.publishedDateIncorrect = false;
      DateValid  = true;
    }
    return DateValid;
  }
}
