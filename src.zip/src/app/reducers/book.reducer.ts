import {Action} from '@ngrx/store';
import {Book} from './../models/book.model';
import * as BookActions from './../actions/book.actions';

 const date = new Date(Date.now());
 const initialState: Book =   {
  id: '1',
  authorName: 'Shahar Nardia',
  publishedDate: '2018-01-01',
  bookTitle: '1@Shahar\'s NGRX Story',
  img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/Redux.png/220px-Redux.png' };

export function reducer(state: Book[]  = [initialState],
  action: BookActions.Actions) {
switch (action.type) {
  case BookActions.ADD_BOOK:
  return [...state, action.payload];

  case BookActions.LOAD_BOOKS:
  return [state, action.payload];

  case BookActions.EDIT_BOOK:
  {
    const book = {
      id: action.payload.id,
      authorName: action.payload.authorName,
      publishedDate: action.payload.publishedDate,
      bookTitle: action.payload.bookTitle,
      img: action.payload.img};
      const b: Book[] = [ ];
      state.splice(action.index, 1);
      return b.concat(state.slice(0, action.index), book, state.slice(action.index, state.length));
  }

  case BookActions.REMOVE_BOOK:
  state.splice(action.payload, 1);
  return state;
  default:
  return state;

}
}
