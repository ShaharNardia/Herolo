import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { StoreModule } from '@ngrx/store';
import { reducer } from './reducers/book.reducer';
import { ReadComponent } from './read/read.component';
import { BookService } from './data/book.service';
import { TitleBookPipe } from './pipes/title-book.pipe';
import { DatePipe } from './pipes/date.pipe';
import { BootstrapModalModule } from 'ng2-bootstrap-modal';
import { DeleteBookPopupComponent } from './popups/delete/delete-popup.component';
import { AddBookPopupComponent } from './popups/add/add-popup.component';
import { NoImgPipe } from './pipes/no-img.pipe';
import { AuthorPipe } from './pipes/no-author.pipe';



@NgModule({
  declarations: [
    AppComponent,
    ReadComponent,
    TitleBookPipe, DatePipe, NoImgPipe, AuthorPipe,
    DeleteBookPopupComponent,
    AddBookPopupComponent
  ],
  entryComponents: [
    DeleteBookPopupComponent,
    AddBookPopupComponent
  ],
  imports: [
    BrowserModule,
    StoreModule.forRoot({ book: reducer }), HttpModule, HttpClientModule,
    BootstrapModalModule.forRoot({container: document.body})

  ],
  providers: [BookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
