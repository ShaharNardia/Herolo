import { Action } from '@ngrx/store';
import { Book } from './../models/book.model';

export const ADD_BOOK = '[BOOK] Add';
export const LOAD_BOOKS = '[BOOK] Load';
export const EDIT_BOOK = '[BOOK] Edit';
export const REMOVE_BOOK = '[BOOK] Remove';

export class AddBook implements Action {
  readonly type = ADD_BOOK;
  constructor(public payload: Book) {}
}

export class LoadBooks implements Action {
  readonly type = LOAD_BOOKS;
  constructor(public payload: Book[]) {}
}

export class EditBook implements Action {
  readonly type = EDIT_BOOK;

  constructor(public payload: Book, public index: number) {}
}

export class RemoveBook implements Action {
  readonly type = REMOVE_BOOK;

  constructor(public payload: number) {}
}

export type Actions = AddBook | EditBook | RemoveBook | LoadBooks;
