export interface Book {
  id: string;
  authorName: string;
  publishedDate: string;
  bookTitle: string;
  img: string;
}
