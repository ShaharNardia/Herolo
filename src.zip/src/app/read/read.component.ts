import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';

import { Book } from '../models/book.model';
import { AppState } from '../app.state';
import { BookService } from '../data/book.service';
import * as BookActions from './../actions/book.actions';
import { DialogService } from 'ng2-bootstrap-modal';
import { DeleteBookPopupComponent } from '../popups/delete/delete-popup.component';
import { AddBookPopupComponent } from '../popups/add/add-popup.component';

@Component({
  selector: 'app-read',
  templateUrl: './read.component.html',
  styleUrls: ['./read.component.css']
})
export class ReadComponent implements OnInit {
  MyDate = new Date(Date.now());
  BooksList: Book[] = [];
  StoreBooksList: Observable<Book[]>;
  dataRecieved;
  arrayLength = 0;

  constructor(private service: BookService,
              private store: Store<AppState>,
              private dialogService: DialogService) {

    this.service.GetGoogleApiBooksResults('a').subscribe(
      data => {
        this.dataRecieved = data;
        this.arrayLength = this.dataRecieved.items.length;
        for (let i = 0; i < this.arrayLength; i++) {
          this.store.dispatch(new BookActions.AddBook({
            id: this.dataRecieved.items[i].id,
            authorName: this.dataRecieved.items[i].volumeInfo.authors,
            publishedDate: this.dataRecieved.items[i].volumeInfo.publishedDate,
            bookTitle: this.dataRecieved.items[i].volumeInfo.title,
            img: this.dataRecieved.items[i].volumeInfo.imageLinks.smallThumbnail
          }));
        }
      },
      err => console.error(err)
    );

    this.StoreBooksList = store.select('book');
  }

  ngOnInit() { }
  openDeleteBookPopup(index) {
    this.dialogService.addDialog(DeleteBookPopupComponent, {
        id: index,
        title: '',
        message: 'Are you sure you would like to delete this book?'
        });
}

openAddBookPopup(book, _index) {

  if (_index !== undefined ) {
    this.dialogService.addDialog(AddBookPopupComponent, {
      index: _index,
      id: book.id,
      authorName: book.authorName,
      publishedDate: book.publishedDate,
      bookTitle: book.bookTitle,
      img: book.img,
      title: 'Edit this book'
      });
  } else {
    this.dialogService.addDialog(AddBookPopupComponent, {
      id: '',
      authorName: '',
      publishedDate: '',
      bookTitle: '',
      img: '',
      title: 'Add a new book'
      });
    }
  }
}
